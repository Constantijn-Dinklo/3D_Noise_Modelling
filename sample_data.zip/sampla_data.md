## Sample data
This folder contains all the required input data. In this file the required steps are explained.

The sample data is a neighbourhood in Rotterdam, in the Netherlands. It is an area of 110 x 90 meters, where aboutn10 receivers were placed. For testing purposes it contains one road.

In order for the algorithm to run correctly, do the following:

1. The Test_Cnossos software should be placed in a folder where the path form the (C:) disk has no spaces.
2. Create a folder 'input' in the code folder of the cloned github reposotory and place all sample files in there.
3. Create a folder called 'objp' in the code folder (for the provided command to work)
4. Create a folder output in the code folder, and a folder xml_output inside the output folder.

In the end the folder structure should look like this:

Code>
    input>
        [all input files]
    objp>
        empty
    output>
        xml [not mandatory]
        xml_output
    [all python and shell files from the release]

When this is done, start git bash from the 'Code' folder or start it and navigate to the correct folder. The run the following command:

./complete.sh input/Constrained_tin.json objp input/semantics_scenario_000.shp input/receiver_points_scenario_000.shp input/single_road_scenario_000.gml output C:/Users/laure/Documents/synthesis/CNOSSOS/cnosses_code/Release . output >> out.txt

Note that the out.txt is optional.